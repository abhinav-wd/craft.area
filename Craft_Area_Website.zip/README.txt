Craft Area — Handmade Website

Brand: Craft Area
Instagram: @craft.area_22
WhatsApp: +91 8009077293

HOW TO USE
1. Extract the ZIP.
2. Keep the 'assets' folder next to index.html.
3. Open index.html in Chrome/Edge.

The website uses the two product photos supplied for this project.
